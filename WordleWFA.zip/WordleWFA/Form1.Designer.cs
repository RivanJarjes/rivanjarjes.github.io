﻿namespace WordleWFA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnlTop = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDebug = new System.Windows.Forms.Label();
            this.lblTriesDebug = new System.Windows.Forms.Label();
            this.lblGameOverDebug = new System.Windows.Forms.Label();
            this.lblDebugFirstLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pnlTop)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.Location = new System.Drawing.Point(-10, -12);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(507, 76);
            this.pnlTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pnlTop.TabIndex = 0;
            this.pnlTop.TabStop = false;
            this.pnlTop.Paint += new System.Windows.Forms.PaintEventHandler(this.PnlTop_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("NYTKarnakCondensed", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(176, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 44);
            this.label1.TabIndex = 1;
            this.label1.Text = "Wordle";
            // 
            // lblDebug
            // 
            this.lblDebug.AutoSize = true;
            this.lblDebug.ForeColor = System.Drawing.Color.White;
            this.lblDebug.Location = new System.Drawing.Point(13, 13);
            this.lblDebug.Name = "lblDebug";
            this.lblDebug.Size = new System.Drawing.Size(37, 13);
            this.lblDebug.TabIndex = 2;
            this.lblDebug.Text = "debug";
            // 
            // lblTriesDebug
            // 
            this.lblTriesDebug.AutoSize = true;
            this.lblTriesDebug.ForeColor = System.Drawing.Color.White;
            this.lblTriesDebug.Location = new System.Drawing.Point(418, 13);
            this.lblTriesDebug.Name = "lblTriesDebug";
            this.lblTriesDebug.Size = new System.Drawing.Size(37, 13);
            this.lblTriesDebug.TabIndex = 3;
            this.lblTriesDebug.Text = "debug";
            // 
            // lblGameOverDebug
            // 
            this.lblGameOverDebug.AutoSize = true;
            this.lblGameOverDebug.ForeColor = System.Drawing.Color.White;
            this.lblGameOverDebug.Location = new System.Drawing.Point(13, 40);
            this.lblGameOverDebug.Name = "lblGameOverDebug";
            this.lblGameOverDebug.Size = new System.Drawing.Size(37, 13);
            this.lblGameOverDebug.TabIndex = 4;
            this.lblGameOverDebug.Text = "debug";
            // 
            // lblDebugFirstLabel
            // 
            this.lblDebugFirstLabel.AutoSize = true;
            this.lblDebugFirstLabel.ForeColor = System.Drawing.Color.White;
            this.lblDebugFirstLabel.Location = new System.Drawing.Point(418, 40);
            this.lblDebugFirstLabel.Name = "lblDebugFirstLabel";
            this.lblDebugFirstLabel.Size = new System.Drawing.Size(37, 13);
            this.lblDebugFirstLabel.TabIndex = 5;
            this.lblDebugFirstLabel.Text = "debug";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(19)))));
            this.ClientSize = new System.Drawing.Size(480, 633);
            this.Controls.Add(this.lblDebugFirstLabel);
            this.Controls.Add(this.lblGameOverDebug);
            this.Controls.Add(this.lblTriesDebug);
            this.Controls.Add(this.lblDebug);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnlTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Wordle";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.pnlTop)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pnlTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDebug;
        private System.Windows.Forms.Label lblTriesDebug;
        private System.Windows.Forms.Label lblGameOverDebug;
        private System.Windows.Forms.Label lblDebugFirstLabel;
    }
}

